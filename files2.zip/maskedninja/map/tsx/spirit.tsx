<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.1" name="spirit" tilewidth="64" tileheight="64" tilecount="16" columns="4">
 <image source="C:/Users/Bartek/Desktop/-/GRA-PYTHON(PETARDA)/SpriteSheet_scaled_4x_pngcrushed (2).png" width="256" height="256"/>
</tileset>
