<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.1" name="Nature64_2" tilewidth="64" tileheight="64" tilecount="336" columns="16">
 <image source="C:/Users/Bartek/Desktop/-/GRA-PYTHON(PETARDA)/xd64x64/NinjaAdventure/Backgrounds/Tilesets/TilesetNature_scaled_4x_pngcrushed.png" width="1024" height="1344"/>
</tileset>
