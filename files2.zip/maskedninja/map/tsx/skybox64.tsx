<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.1" name="skybox64" tilewidth="64" tileheight="64" tilecount="90" columns="10">
 <image source="C:/Users/Bartek/Desktop/-/GRA-PYTHON(PETARDA)/xd64x64/NinjaAdventure/Palette_scaled_64x_pngcrushed.png" width="640" height="576"/>
</tileset>
