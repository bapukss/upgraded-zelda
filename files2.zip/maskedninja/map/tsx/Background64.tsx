<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.1" name="Background64" tilewidth="64" tileheight="64" tilecount="572" columns="22">
 <image source="C:/Users/Bartek/Desktop/-/GRA-PYTHON(PETARDA)/xd64x64/NinjaAdventure/Backgrounds/Tilesets/TilesetFloor_scaled_4x_pngcrushed.png" width="1408" height="1668"/>
</tileset>
