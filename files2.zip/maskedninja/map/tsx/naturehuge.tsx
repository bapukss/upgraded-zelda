<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.1" name="naturehuge" tilewidth="128" tileheight="128" tilecount="80" columns="8">
 <image source="C:/Users/Bartek/Desktop/-/GRA-PYTHON(PETARDA)/xd64x64/NinjaAdventure/Backgrounds/Tilesets/TilesetNature_scaled_4x_pngcrushed.png" width="1024" height="1344"/>
</tileset>
