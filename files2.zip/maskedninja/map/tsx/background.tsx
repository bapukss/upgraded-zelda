<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.1" name="background" tilewidth="16" tileheight="16" tilecount="572" columns="22">
 <image source="C:/Users/Bartek/Desktop/-/GRA-PYTHON(PETARDA)/xd/NinjaAdventure/Backgrounds/Tilesets/TilesetFloor.png" width="352" height="417"/>
</tileset>
