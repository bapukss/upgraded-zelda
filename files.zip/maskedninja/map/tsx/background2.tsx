<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.1" name="background2" tilewidth="16" tileheight="16" tilecount="77" columns="11">
 <image source="C:/Users/Bartek/Desktop/-/GRA-PYTHON(PETARDA)/xd/NinjaAdventure/Backgrounds/Tilesets/TilesetFloorB.png" width="176" height="112"/>
</tileset>
